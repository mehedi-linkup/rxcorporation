<?php $__env->startPush('admin-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/css/dataTables.bootstrap4.min">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-content'); ?>
<div class="container-fluid">

    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <h4 class="page-title">Generate Barcode</h4>
                
                
                
                <div class="state-information d-none d-sm-block">
                    
                    <div class="state-graph">
                        <div id="header-chart-2"></div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="page-content-wrapper">
        <?php if($errors->any()): ?>
            <div class="alert alert-primary">
                <ol>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="text-danger"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            </div>
        <?php endif; ?>
    </div> <!-- container-fluid -->

    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card m-b-20">
                <div class="card-body">
                    <form action="<?php echo e(route('barcode.store')); ?>" method="post" id="productForm">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-3">
                                <div class="form-group">
                                    <label>Product <span class="text-primary">*</span></label>
                                    <div>
                                       <select name="product_id" id="productId" class="form-control">
                                           <option value=""> Select Product</option>
                                           <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <option value="<?php echo e($item->id); ?>"> <?php echo e($item->name); ?></option>    
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </select>
                                       <span class="text-danger" id="productId-error"></span>      
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2">
                                <div class="form-group">
                                    <label for="number">Number <span class="text-primary">*</span> </label>
                                    <div>
                                        <input name="number" type="number" value="<?php echo e(old('number')); ?>"  class="form-control" id="number"  placeholder="Number of QR code"/>
                                        <span class="text-danger" id="number-error"></span>
                                    </div>
                                </div>
                            </div>
                           
                            <div class="col-lg-3 d-flex align-items-center">
                                <button type="submit" class="btn btn-info mt-2 mr-auto">Generate</button>
                            </div>
                            <div class="col-lg-12">
                                <div id="success-message"></div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <a href="#!" onclick="printDiv('barcodeShow')">print</a>     
</div>
<div class="container-fluid">
    <div id="barcodeShow" class="row">   
        <style>
           
                .container-fluid {
                    width: 100%;
                    padding-right: 15px;
                    padding-left: 15px;
                    margin-right: auto;
                    margin-left: auto;
                }
                .row {
                    display: -ms-flexbox;
                    display: flex;
                    -ms-flex-wrap: wrap;
                    flex-wrap: wrap;
                    margin-right: -15px;
                    margin-left: -15px;
                }
                .col-lg-3 {
                    -ms-flex: 0 0 25%;
                    flex: 0 0 25%;
                    max-width: 25%;
                }
               
            
        </style> 
        
        <?php for($i=0; $i<@$loopArr['item']; $i++): ?>
        
        <div class="col-lg-3 py-4">
            
            <img src="data:image/png;base64,<?php echo e(DNS2D::getBarcodePNG(asset($url), 'QRCODE',6, 6)); ?>" alt="barcode" />
        </div>
        <?php endfor; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>
    
    <script>
        function printDiv(divName) {
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\rxcorporation\resources\views/admin/barcode/index.blade.php ENDPATH**/ ?>