
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>Admin Dashboard</title>
        <meta content="Admin Dashboard" name="description" />
        <meta content="Themesbrand" name="author" />
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <?php echo $__env->yieldPushContent('admin-css'); ?>
        <link href="<?php echo e(asset('admin')); ?>/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('admin')); ?>/css/metismenu.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('admin')); ?>/css/icons.css" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('admin')); ?>/css/style.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/css/toastr.min.css">
        <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/css/custom.css">
       
        
    </head>

    <body>
        <?php echo Toastr::message(); ?>

        <!-- Begin page -->
        <div id="wrapper">

            <?php echo $__env->make('partial.admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- ========== Left Sidebar Start ========== -->
            <?php echo $__env->make('partial.admin_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <?php echo $__env->yieldContent('admin-content'); ?>
                    

                </div> <!-- content -->

                <?php echo $__env->make('partial.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>



        </div>
        <!-- END wrapper -->
            

        <!-- jQuery  -->
        <script src="<?php echo e(asset('admin')); ?>/js/jquery.min.js"></script>
        
        <script src="<?php echo e(asset('admin')); ?>/js/validate.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/js/metisMenu.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/js/jquery.slimscroll.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/js/waves.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/js/all.min.js"></script>
        <!-- App js -->
        <script src="<?php echo e(asset('admin')); ?>/js/app.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/js/toastr.min.js"></script>
        
        <script>
            <?php if(Session::has('success')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true
            }
                    toastr.success("<?php echo e(session('success')); ?>");
            <?php endif; ?>
    
          
    
            <?php if(Session::has('update')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true
            }
                    toastr.success("<?php echo e(session('update')); ?>");
            <?php endif; ?>
    
            <?php if(Session::has('message')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true
            }
                    toastr.success("<?php echo e(session('message')); ?>");
            <?php endif; ?>
          
            <?php if(Session::has('remove')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true
            }
                    toastr.error("<?php echo e(session('remove')); ?>");
            <?php endif; ?>
            
            <?php if(Session::has('error')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true
            }
                    toastr.error("<?php echo e(session('error')); ?>");
            <?php endif; ?>
           
          
        </script>
        <?php echo $__env->yieldPushContent('admin-js'); ?>

    </body>

</html><?php /**PATH D:\xampp\htdocs\aztibd\resources\views/layouts/admin.blade.php ENDPATH**/ ?>