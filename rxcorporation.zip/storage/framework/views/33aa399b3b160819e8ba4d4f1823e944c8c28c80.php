<div class="left side-menu">
    <div class="slimscroll-menu" id="remove-scroll">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu" id="side-menu">
                <li class="menu-title">Main</li>
                <li>
                    <a href="<?php echo e(route('dashboard')); ?>" class="waves-effect">
                        <i class="fas fa-home"></i> <span> Dashboard </span>
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0);" class="waves-effect"><i class="fab fa-product-hunt"></i><span> Product <span class="float-right menu-arrow"><i class="mdi mdi-plus"></i></span> </span></a>
                    <ul class="submenu">
                        <li><a href="<?php echo e(route('category.index')); ?>">Category</a></li>
                        <li><a href="<?php echo e(route('product.index')); ?>">Product</a></li>
                    </ul>
                </li>
              
                <li>
                    <a href="javascript:void(0);" class="waves-effect"><i class="fas fa-book"></i><span> Website Content <span class="float-right menu-arrow"><i class="mdi mdi-plus"></i></span> </span></a>
                    <ul class="submenu">
                        <li><a href="<?php echo e(route('gallery.index')); ?>">Gallery</a></li>
                        <li><a href="<?php echo e(route('service.index')); ?>">Service</a></li>
                        <li><a href="<?php echo e(route('counter.index')); ?>">Counter</a></li>
                        <li><a href="<?php echo e(route('partner.index')); ?>">Partner</a></li>
                        <li><a href="<?php echo e(route('management.index')); ?>">Management</a></li>
                        <li><a href="<?php echo e(route('team.index')); ?>">Team</a></li>
                        <li><a href="<?php echo e(route('slider.index')); ?>">Slider</a></li>
                        <li><a href="<?php echo e(route('specialize.index')); ?>">Specialize</a></li>
                    </ul>
                </li>
               
                <li>
                    <a href="<?php echo e(route('post.index')); ?>" class="waves-effect"><i class="fas fa-newspaper"></i><span>Post </span></a>
                    
                </li>
                <li>
                    <a href="<?php echo e(route('contact.list')); ?>" class="waves-effect"><i class="fas fa-address-book"></i><span> Message From Website</span></a>
                   
                </li>
                <li>
                    <a href="javascript:void(0);" class="waves-effect"><i class="fas fa-wrench"></i><span> Setting <span class="float-right menu-arrow"><i class="mdi mdi-plus"></i></span> </span></a>
                    <ul class="submenu">
                        <li><a href="<?php echo e(route('company.profile')); ?>">Company Profile</a></li>
                        <li><a href="<?php echo e(route('about.us.edit')); ?>">About Us</a></li>
                        <li><a href="<?php echo e(route('user.index')); ?>"> User List</a></li>
                        <li><a href="<?php echo e(route('user.create')); ?>"> User Create</a></li>
                        <li><a href="<?php echo e(route('auth.profile.edit')); ?>">Update Profile</a></li>
                        <li><a href="<?php echo e(route('password.change')); ?>">Change Password</a></li>
                    </ul>
                </li>
                <li>
                    <a href="<?php echo e(route('logout')); ?>" onclick="return confirm('Are you sure ! Logout from Admin Panel')" class="waves-effect"><i class="fas fa-sign-out-alt"></i><span>Log Out </span></a>
                    
                </li>

            </ul>

        </div>
        <!-- Sidebar -->
        <div class="clearfix"></div>

    </div>
    <!-- Sidebar -left -->

</div>
<!-- Left Sidebar End --><?php /**PATH /home/dewbxcak/rxcorporationbd.com/resources/views/partial/admin_sidebar.blade.php ENDPATH**/ ?>