
<?php $__env->startSection('website-content'); ?>
<main id="main">
    <div class="breadcrumbs" data-aos="fade-in">
        <div class="container">
          <h2><?php echo e($post->title); ?></h2>
          
        </div>
      </div><!-- End Breadcrumbs -->
  
      <!-- ======= Cource Details Section ======= -->
      <section id="course-details" class="course-details">
        <div class="container" data-aos="fade-up">
  
          <div class="row">
            <div class="col-lg-8">
              <img src="<?php echo e(asset($post->image)); ?>" class="img-fluid" alt="">
              <h3><?php echo e($post->title); ?></h3>
              <p>
                <?php echo $post->description; ?>

              </p>
            </div>
            <div class="col-lg-4">
              <div class="section-title">Recent Post</div>
              <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="course-info d-flex justify-content-between align-items-center">
                <a href="<?php echo e(route('post.details',$item->slug)); ?>"><h5><?php echo e($item->title); ?></h5></a>
                
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
  
            </div>
          </div>
  
        </div>
      </section><!-- End Cource Details Section -->

  </main>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('website-js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\aztibd\resources\views/website/post_details.blade.php ENDPATH**/ ?>