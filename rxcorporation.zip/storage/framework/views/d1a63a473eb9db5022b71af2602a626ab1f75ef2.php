<?php $__env->startPush('admin-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/css/dataTables.bootstrap4.min">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-content'); ?>
<div class="container-fluid">

    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <h4 class="page-title">Category Add</h4>

                <div class="state-information d-none d-sm-block">
                    <div class="state-graph">
                        <div id="header-chart-1"></div>
                        
                    </div>
                    <div class="state-graph">
                        <div id="header-chart-2"></div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<div class="page-content-wrapper">
    <?php if($errors->any()): ?>
        <div class="alert alert-primary">
            <ol>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="text-danger"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card mb-20">
                <div class="card-body">
                    <form action="<?php echo e(route('category.store')); ?>" method="post" enctype="multipart/form-data" id="categoryForm">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Name <span class="text-primary">*</span></label>
                                    <div>
                                        <input  name="name" type="text" value="<?php echo e(old('name')); ?>"  class="form-control" id="name"  placeholder="Enter category name"/>
                                                
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Image</label>
                                    <div>
                                        <input  name="image" type="file"  class="form-control" onchange="aboutUrl(this);" />    
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                               
                                <div class="form-group mt-3 text-center">
                                    <img src="" alt="" id="previewImage">
                                    
                                </div>
                            </div>
                            
                            
                        </div>
                        <button type="submit" class="btn btn-info">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card m-b-20">
                <div class="card-body">
                    <h4 class="mt-0 header-title">Category Table</h4>
                    

                    <table id="example" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr class="text-center">
                                <th>SL</th>
                                <th>Name</th>
                                <th>Image</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td width="30%"><?php echo e($item->name); ?></td>
                                <td class="text-center">
                                    <img src="<?php echo e(asset($item->image)); ?>" alt="" class="slider-table-img">
                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('category.edit',$item->id)); ?>" class="btn btn-info"><i class="fas fa-edit"></i></a>
                                   
                                    <button type="submit" class="btn btn-primary" onclick="deleteUser(<?php echo e($item->id); ?>)"><i class="fas fa-trash"></i></button>
                                        <form id="delete-form-<?php echo e($item->id); ?>" action="<?php echo e(route('category.destroy', $item)); ?>"
                                            method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                        </tbody>
                    </table>
              
                    
                </div>
            </div>
         </div> <!-- end col -->
    </div> <!-- end row -->  
</div> <!-- container-fluid -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>
<script src="<?php echo e(asset('admin')); ?>/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/sweetalert2.all.js"></script>
<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<script> 
    function aboutUrl(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload=function(e) {
                    $('#previewImage')
                        .attr('src', e.target.result)
                        .width(100)
                        .height(100);
                       
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
        document.getElementById("previewImage").src="/noimage.png";
        
    </script>
    <script>
          function deleteUser(id) {
            swal({
                title: 'Are you sure?',
                text: "You want to Delete this!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                confirmButtonClass: 'btn btn-success',
                cancelButtonClass: 'btn btn-danger',
                buttonsStyling: false,
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    event.preventDefault();
                    document.getElementById('delete-form-' + id).submit();
                } else if (
                    // Read more about handling dismissals
                    result.dismiss === swal.DismissReason.cancel
                ) {
                    swal(
                        'Cancelled',
                        'Your data is safe :)',
                        'error'
                    )
                }
            })
        }
    </script>
       <script>
 
        $(document).ready(function () {
        $('#categoryForm').validate({ // initialize the plugin
            rules: {
                name: {
                    required: true
                },
            }
        });
         
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\rxcorporation\resources\views/admin/category/index.blade.php ENDPATH**/ ?>