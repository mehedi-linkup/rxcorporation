<?php $__env->startPush('admin-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/css/dataTables.bootstrap4.min">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-content'); ?>
<div class="container-fluid">

    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <h4 class="page-title">Team Table</h4>

                <div class="state-information d-none d-sm-block">
                    <div class="state-graph">
                        <div id="header-chart-1"></div>
                        <div class="info"><a href="<?php echo e(route('team.index')); ?>" class="btn btn-primary">Back</a></div>
                    </div>
                    <div class="state-graph">
                        <div id="header-chart-2"></div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<div class="page-content-wrapper">
    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                            <ol>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="text-danger"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                        </div>
                    <?php endif; ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card mb-20">
                <div class="card-body">
                    <form action="<?php echo e(route('team.update',$team->id)); ?>" method="post" enctype="multipart/form-data" id="managementForm">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Name <span class="text-primary">*</span></label>
                                    <div>
                                        <input  name="name" type="text" value="<?php echo e($team->name); ?>"  class="form-control" id="name"  placeholder="Enter Name"/>
                                                
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Designation <span class="text-primary">*</span></label>
                                    <div>
                                        <input  name="designation" value="<?php echo e($team->designation); ?>" type="text"  class="form-control"  placeholder="Enter Designation"/>
                                               
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Facebook</label>
                                    <div>
                                        <input  name="facebook"  type="url" value="<?php echo e($team->facebook); ?>"  class="form-control"  placeholder="Facebook Link"/>
                                              
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Twitter</label>
                                    <div>
                                        <input  name="twitter"  value="<?php echo e($team->twitter); ?>" type="url"  class="form-control"  placeholder="Twitter Link"/>
                                                
                                    </div>
                                </div>
                               
                              
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Instagram</label>
                                    <div>
                                        <input  name="instagram"  value="<?php echo e($team->instagram); ?>" type="url"  class="form-control"  placeholder="Instagram Link"/>
                                            
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Linkedin</label>
                                    <div>
                                        <input  name="linkedin"  value="<?php echo e($team->linkedin); ?>" type="url"  class="form-control"  placeholder="Linkedin Link"/>
                                            
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Image</label>
                                    <div>
                                        <input  name="image" type="file"  class="form-control" onchange="aboutUrl(this);" />
                                               
                                                <br/>
                                                <img src="" alt="" id="previewImage">
                                    </div>
                                </div>
                            </div>
                            
                            
                        </div>
                        <button type="submit" class="btn btn-info">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div> <!-- container-fluid -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>
<script> 
    function aboutUrl(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload=function(e) {
                    $('#previewImage')
                        .attr('src', e.target.result)
                        .width(100)
                        .height(100);
                       
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
        document.getElementById("previewImage").src="<?php echo e(asset($team->image)); ?>";
        
    </script>
        <script>
            $('#managementForm').validate({ // initialize the plugin
            
               rules: {
            
                   name: {
                       required: true
            
                   },
                   designation: {
            
                   required: true
           
                   },
                   image: {
            
                   required: true
           
                   },
            
               }
           
            
           });
            
           </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\aztibd\resources\views/admin/team/edit.blade.php ENDPATH**/ ?>