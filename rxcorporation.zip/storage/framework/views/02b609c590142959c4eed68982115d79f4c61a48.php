<?php $__env->startPush('admin-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/css/dataTables.bootstrap4.min">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-content'); ?>
<div class="container-fluid">

    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <h4 class="page-title">Counter Edit</h4>

                <div class="state-information d-none d-sm-block">
                    <div class="state-graph">
                        <div id="header-chart-1"></div>
                        
                    </div>
                    <div class="state-graph">
                        <div id="header-chart-2"></div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<div class="page-content-wrapper">
    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                            <ol>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="text-danger"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                        </div>
                    <?php endif; ?>
    <div class="row justify-conter-center">
        <div class="col-lg-12">
            <div class="card mb-20">
                <div class="card-body">
                    <form action="<?php echo e(route('counter.update',$counter->id)); ?>" method="post" enctype="multipart/form-data" id="counterForm">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row justify-conter-center">
                            <div class="col-lg-5">
                                <div class="form-group">
                                    <label>Name <span class="text-primary">*</span></label>
                                    <div>
                                        <input  name="name" type="text" value="<?php echo e($counter->name); ?>"  class="form-control" id="name"  placeholder="Enter counter name"/>
                                                
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5">
                                <div class="form-group">
                                    <label>Number <span class="text-primary">*</span></label>
                                    <div>
                                        <input  name="number" type="number" value="<?php echo e($counter->number); ?>"  class="form-control" id="number"  placeholder="Enter counter number"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2 counter-save">
                                <button type="submit" class="btn btn-info">Update</button>
                            </div>
                            
                        </div>
                       
                    </form>
                </div>
            </div>
        </div>
    </div>
</div> <!-- container-fluid -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>
    <script>
        $(document).ready(function () {
        $('#counterForm').validate({ // initialize the plugin
            rules: {
                name: {
                    required: true
                },
                number: {
                    required: true,
                },
            }
        });
         
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\aztibd\resources\views/admin/counter/edit.blade.php ENDPATH**/ ?>