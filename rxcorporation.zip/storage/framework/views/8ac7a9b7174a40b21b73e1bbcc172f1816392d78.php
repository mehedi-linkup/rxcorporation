
<?php $__env->startSection('website-content'); ?>
<main id="main">

    <div class="breadcrumbs" data-aos="fade-in">
        <div class="container">
          <h2>Product</h2>
        </div>
      </div><!-- End Breadcrumbs -->
      <section>
        <div class="container" data-aos="fade-up">
            <div class="row" data-aos="zoom-in" data-aos-delay="100">
              <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-3 d-flex align-items-stretch">
                    <div class="product w-100">
                        <a href="<?php echo e(route('product.details',$item->slug)); ?>">
                            <img src="<?php echo e(asset($item->image)); ?>" alt="" class="w-100 p-3 product-image">
                            <hr/>
                          <div class="product-info d-flex w-100">
                            <div class="">
                              <p class="text-black mx-2 fw-bolder">Name </p>
                              <p class="text-black mx-2 fw-bolder">Price</p>
                              <p class="text-black mx-2 fw-bolder">Type</p>
                            </div>
                            <div>
                              <p class="text-black mx-2 fw-bolder">:</p>
                              <p class="text-black mx-2 fw-bolder">:</p>
                              <p class="text-black mx-2 fw-bolder">:</p>
                            </div>
                            <div class="">
                              <p><?php echo e($item->name); ?></p>
                              <p><?php echo e($item->price); ?></p>
                              <p><?php echo e($item->category->name); ?></p>
                            </div>
                          </div>
                        </a>
                    </div>
                </div>  
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
    
          </div>
      </section>

  </main>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('website-js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\aztibd\resources\views/website/product.blade.php ENDPATH**/ ?>