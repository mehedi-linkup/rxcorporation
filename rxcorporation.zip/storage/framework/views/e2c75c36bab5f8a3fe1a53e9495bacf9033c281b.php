<footer class="footer">
     © <?php echo date('Y') ?> AZ Trade International <span class="d-none d-sm-inline-block">- Developed <i class="mdi mdi-heart text-danger"></i> by Link Up Technology</span>
</footer><?php /**PATH D:\xampp\htdocs\aztibd\resources\views/partial/admin_footer.blade.php ENDPATH**/ ?>