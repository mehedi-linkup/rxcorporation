
<?php $__env->startSection('website-content'); ?>
<main id="main">

    <div class="breadcrumbs" data-aos="fade-in">
        <div class="container">
          <h2>Product Details</h2>
        </div>
      </div><!-- End Breadcrumbs -->
      <section>
        <div class="container" data-aos="fade-up">
            <div class="row" data-aos="zoom-in" data-aos-delay="100">
                <div class="col-lg-6 col-md-6 text-center overflow-hidden product-details-img">
                    <img src="<?php if(isset($item->image)): ?><?php echo e(asset($item->image)); ?><?php endif; ?>" alt="" class="w-100 product-details-img">
                </div>
                <div class="col-lg-6">
                    <h3><span class="me-2 text-success">Product Name:</span><?php if(isset($item->name)): ?><?php echo e($item->name); ?><?php endif; ?></h3>
                    <p><span class="me-2 text-success">Category:</span> <?php if(isset($item->category->name)): ?><?php echo e($item->category->name); ?><?php endif; ?></p>
                    <p><span class="me-2 text-success">Price</span> <?php if(isset($item->price)): ?><?php echo e($item->price); ?><?php endif; ?></p>
                    <p><?php if(isset($item->description)): ?><?php echo $item->description; ?><?php endif; ?></p>
                </div>
            </div>
    
          </div>
      </section>

  </main>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('website-js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\aztibd\resources\views/website/product_details.blade.php ENDPATH**/ ?>