
<?php $__env->startPush('website-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('website/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('website/css/owl.theme.default.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('website-content'); ?>
    <section class="slider-section">
        <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-indicators">
                <?php
                    $count = $slider->count();
                ?>
                <?php for($i = 0; $i < $count; $i++): ?>
                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="<?php echo e($i); ?>"
                        class="<?php echo e($i == 0 ? 'active' : ''); ?>" aria-current="true" aria-label="Slide 1"></button>
                <?php endfor; ?>
            </div>
            <div class="carousel-inner">
                <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">
                        <div id="hero" class="d-flex justify-content-center align-items-center"
                            style="background-image: url(<?php echo e(asset($item->image)); ?>)">
                            <div class="container position-relative d-none d-md-block" data-aos="zoom-in" data-aos-delay="100">
                                <h1><?php echo e($item->title); ?></h1>
                                <h2><?php echo e($item->short_description); ?></h2>
                                <a href="<?php echo e(route('home')); ?>" class="btn-get-started">Get Started</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </section>

    <main id="main">

        <!-- ======= About Section ======= -->
        <section id="about" class="about">
            <div class="container" data-aos="fade-up">
                <div class="row">
                    <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-left" data-aos-delay="100">
                        <img src="<?php echo e($content->about_image); ?>" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                        <h3>About <?php echo $content->company_name; ?></h3>
                        <p class="fst-italic">
                            <?php echo $content->about_description; ?>

                        </p>
                    </div>
                </div>

            </div>
        </section><!-- End About Section -->

        <section id="category" class="category">
            <div class="container">
                <div class="section-title">
                    <h2 class="mb-3">Product Categories</h2>
                </div>
                <div class="row">
                    <div class="col-lg-12" data-aos="fade-up" data-aos-delay="600">
                        <div class="owl-carousel owl-theme">
                            <?php $__currentLoopData = $category->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->image): ?>
                                <div class="item">
                                    <div class="card text-center" style="border:none">
                                        <div class="img-box border">
                                            <img src="<?php echo e($item->image); ?>" class="card-img-top"
                                            alt="<?php echo e($item->name); ?>">
                                            <a class="category-link" href="<?php echo e(route('product-cat.show', $item->slug)); ?>"></a>
                                        </div>
                                        <div class="card-body pt-2">
                                           <a href="<?php echo e(route('product-cat.show', $item->slug)); ?>" class="btn mt-2 rounded-0 mb-0"><?php echo e($item->name); ?></a>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
        </section>

        <section id="feature-product" class="feature-product">
            <div class="container">
                <div class="section-title">
                    <h2 class="mb-3">Featured Product</h2>
                </div>
                <div class="row" data-aos="fade-up" data-aos-delay="600">
                    <?php $__currentLoopData = $product->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3">
                        <div class="card border-0">
                            <div class="img-box p-lg-3">
                                <img src="<?php echo e($item->image); ?>" class="card-img-top" alt="<?php echo e($item->image); ?>">
                                <a class="img-link" href="<?php echo e(route('product.details', $item->slug)); ?>"></a>
                            </div>
                            <div class="card-body">
                              <a href="<?php echo e(route('product.details', $item->slug)); ?>" class="d-block card-title text-center"><?php echo e($item->name); ?></a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>

        <!-- ======= Counts Section ======= -->
        

        <!-- ======= Why Us Section ======= -->
        


        <!-- ======= Popular Courses Section ======= -->
        

        <section class="bg-light py-4">
            <div class="container">
                <div class="section-title">
                    <h2 class="mb-3">Our Gallery</h2>
                </div>
                <div class="row" data-aos="fade-up" data-aos-delay="600">
                    <?php $__currentLoopData = $gallery->take(12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 mt-3 cart-hover">
                            <div class="card gallery gallery-image w-100">
                                <a href="<?php echo e(asset($item->image)); ?>"><img src="<?php echo e(asset($item->image)); ?>" class="w-100"
                                        alt="" title="Beautiful Image" /></a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </section>
        <!-- ======= Trainers Section ======= -->
        

    </main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('website-js'); ?>
    <script src="<?php echo e(asset('website/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('website/js/jquery.fancybox.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            // add all to same gallery
            $(".gallery a").attr("data-fancybox", "mygallery");
            // assign captions and title from alt-attributes of images:
            $(".gallery a").each(function() {
                $(this).attr("data-caption", $(this).find("img").attr("alt"));
                $(this).attr("title", $(this).find("img").attr("alt"));
            });
            // start fancybox:
            $(".gallery a").fancybox();
        });
    </script>
    <script>
        $(document).ready(function() {
            $(".gallery a").fancybox();
        });
        $('.owl-carousel').owlCarousel({
            loop: true,
            margin: 60,
            dots:false,
            nav: true,
            // autoplay:true,
            // autoplayTimeout:1000,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 3
                },
                1000: {
                    items: 4
                }
            }
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\rxcorporation\resources\views/website/index.blade.php ENDPATH**/ ?>