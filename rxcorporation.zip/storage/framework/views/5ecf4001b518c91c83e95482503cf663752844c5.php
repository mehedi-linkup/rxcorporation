<?php $__env->startPush('admin-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/css/dataTables.bootstrap4.min">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-content'); ?>
<div class="container-fluid">

    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <h4 class="page-title">Gallery Edit</h4>

                <div class="state-information d-none d-sm-block">
                    <div class="state-graph">
                        <div id="header-chart-1"></div>
                        <div class="info"><a href="<?php echo e(route('category.index')); ?>" class="btn btn-primary">Back</a></div>
                    </div>
                    <div class="state-graph">
                        <div id="header-chart-2"></div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<div class="page-content-wrapper">
    <?php if($errors->any()): ?>
        <div class="alert alert-primary">
                <ol>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="text-danger"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            </div>
        <?php endif; ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card mb-20">
                <div class="card-body">
                    <form action="<?php echo e(route('category.update',$category->id)); ?>" method="post" enctype="multipart/form-data" id="categoryForm">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Name</label>
                                    <div>
                                        <input  name="name" type="text" value="<?php echo e($category->name); ?>"  class="form-control" id="name"  placeholder="Enter Title"/>
                                                
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Image</label>
                                    <div>
                                        <input  name="image" type="file"  class="form-control" onchange="aboutUrl(this);" />    
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                               
                                <div class="form-group mt-3 text-center">
                                    <img src="" alt="" id="previewImage">
                                    
                                </div>
                            </div>
                            
                            
                        </div>
                        <button type="submit" class="btn btn-info">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div> <!-- container-fluid -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>
<script> 
    function aboutUrl(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload=function(e) {
                    $('#previewImage')
                        .attr('src', e.target.result)
                        .width(100)
                        .height(100);
                       
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
        document.getElementById("previewImage").src="<?php echo e(asset($category->image)); ?>";
        
    </script>
     <script>
 
        $(document).ready(function () {
        $('#categoryForm').validate({ // initialize the plugin
            rules: {
                name: {
                    required: true
                },
            }
        });
         
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\aztibd\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>