
<?php $__env->startSection('website-content'); ?>
<main id="main">

    <div class="breadcrumbs" data-aos="fade-in">
        <div class="container">
          <h2>Gallery</h2>
        </div>
      </div><!-- End Breadcrumbs -->
      <section class="bg-light py-4">
        <div class="container">
            <div class="row">
              <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-3">
                      <div class="card gallery gallery-image w-100">
                          <a href="<?php echo e(asset($item->image)); ?>"><img src="<?php echo e(asset($item->image)); ?>" class="w-100" alt="" title="Beautiful Image" /></a>
                         
                      </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </div>
        </div>
    </section>

  </main>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('website-js'); ?>
<script src="<?php echo e(asset('website/js/jquery.fancybox.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        // add all to same gallery
        $(".gallery a").attr("data-fancybox", "mygallery");
        // assign captions and title from alt-attributes of images:
        $(".gallery a").each(function() {
            $(this).attr("data-caption", $(this).find("img").attr("alt"));
            $(this).attr("title", $(this).find("img").attr("alt"));
        });
        // start fancybox:
        $(".gallery a").fancybox();
    });
</script>
<script>
    $(document).ready(function() {
        $(".gallery a").fancybox();
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\rxcorporation\resources\views/website/gallery.blade.php ENDPATH**/ ?>