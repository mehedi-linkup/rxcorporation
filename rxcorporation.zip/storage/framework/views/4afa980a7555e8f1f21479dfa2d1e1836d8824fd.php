

<?php $__env->startSection('website-content'); ?>
<section class="slider-section">
  <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
      <?php
      $count = $slider->count();
      ?>
      <?php for($i = 0; $i < $count; $i++): ?>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="<?php echo e($i); ?>" class="<?php echo e($i== 0 ? 'active' : ''); ?>"
          aria-current="true" aria-label="Slide 1"></button>
         
      <?php endfor; ?>  
    </div>
    <div class="carousel-inner">
      <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">
      <div id="hero" class="d-flex justify-content-center align-items-center" style="background-image: url(<?php echo e(asset($item->image)); ?>)">
        <div class="container position-relative" data-aos="zoom-in" data-aos-delay="100">
          <h1><?php echo e($item->title); ?></h1>
          <h2><?php echo e($item->short_description); ?></h2>
          <a href="<?php echo e(route('home')); ?>" class="btn-get-started">Get Started</a>
        </div>
      </div>
    </div> 
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
</section>

<main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">
        <div class="row">
          <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-left" data-aos-delay="100">
            <img src="<?php echo e($content->about_image); ?>" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
            <h3>About <?php echo $content->company_name; ?></h3>
            <p class="fst-italic">
             <?php echo $content->about_description; ?>

            </p>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Counts Section ======= -->
    <section id="counts" class="counts section-bg">
      <div class="container">
        <div class="row counters">
          <?php $__currentLoopData = $counter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-3 col-6 text-center">
            <span data-purecounter-start="0" data-purecounter-end="<?php echo e($item->number); ?>" data-purecounter-duration="1" class="purecounter"></span>
            <p><?php echo e($item->name); ?></p>
          </div> 
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

      </div>
    </section><!-- End Counts Section -->

    <!-- ======= Why Us Section ======= -->
    <section id="why-us" class="why-us">
      <div class="container" data-aos="fade-up">
        <div class="row">
          <div class="col-lg-4 d-flex align-items-stretch">
            <div class="content">
              <h3><?php echo e($special_first->title); ?></h3>
              <p>
                <?php echo $special_first->description; ?>

              </p>
            </div>
          </div>

          <div class="col-lg-8 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-boxes d-flex flex-column justify-content-center">
              <div class="row">
                <?php $__currentLoopData = $specialize; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-4 d-flex align-items-stretch">
                  <div class="card cart-hover">
                    <img src="<?php echo e(asset($item->image)); ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h5 class="card-title"><?php echo e($item->title); ?></h5>
                      <p class="card-text"><?php echo $item->description; ?></p>
                    </div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div><!-- End .content-->
          </div>
        </div>

      </div>
    </section><!-- End Why Us Section -->
  

    <!-- ======= Popular Courses Section ======= -->
    <section id="popular-courses" class="courses">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Post</h2>
          <p>Popular post</p>
        </div>

        <div class="row" data-aos="zoom-in" data-aos-delay="100">
          <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="course-item cart-hover">
              <a href="<?php echo e(route('post.details',$item->slug)); ?>">
              <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid" alt="image">
            </a>
              <div class="course-content">
                <div class="d-flex justify-content-between align-items-center mb-3">
                </div>
                <h3><a href="<?php echo e(route('post.details',$item->slug)); ?>"><?php echo e($item->title); ?></a></h3>
                <p><?php echo $item->short_details; ?></p>
                <div class="trainer d-flex justify-content-between align-items-center">
                  <div class="trainer-profile d-flex align-items-center">
                    <img src="<?php echo e(asset($item->user->image)); ?>" class="img-fluid" alt="">
                    <span><?php echo e($item->user->username); ?></span>
                  </div>
                  <div class="trainer-rank d-flex align-items-center">
                    <i class="far fa-clock mx-1"></i>
                    <?php echo e($item->created_at->format('d/m/Y')); ?>

                    
                  </div>
                </div>
              </div>
            </div>
          </div> <!-- End Course Item-->
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

      </div>
    </section><!-- End Popular Courses Section -->

    <section class="bg-light py-4">
      <div class="container">
          <div class="section-title">
              <h2 class="mb-3">Our Gallery</h2>   
          </div>
          <div class="row">
            <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 mt-3 cart-hover">
                  <div class="card gallery gallery-image w-100">
                      <a href="<?php echo e(asset($item->image)); ?>"><img src="<?php echo e(asset($item->image)); ?>" class="w-100" alt="" title="Beautiful Image" /></a>
                  </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </div>
      </div>
  </section>
    <!-- ======= Trainers Section ======= -->
    <section id="trainers" class="trainers">
      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <h2 class="mb-3">Management</h2>   
      </div>
        <div class="row" data-aos="zoom-in" data-aos-delay="100">
          <?php $__currentLoopData = $management; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-3 col-md-3 d-flex align-items-stretch">
            <div class="member">
              <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid" alt="">
              <div class="member-content">
                <h4><?php echo e($item->name); ?></h4>
                <span><?php echo e($item->designation); ?></span>
                
                <div class="social">
                  <a href="<?php echo e($item->twitter); ?>" target="_blank"><i class="bi bi-twitter"></i></a>
                  <a href="<?php echo e($item->facebook); ?>" target="_blank"><i class="bi bi-facebook"></i></a>
                  <a href="<?php echo e($item->instagram); ?>" target="_blank"><i class="bi bi-instagram"></i></a>
                  <a href="<?php echo e($item->linkedin); ?>" target="_blank"><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>  
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         

        </div>

      </div>
    </section><!-- End Trainers Section -->

  </main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('website-js'); ?>
<script src="<?php echo e(asset('website/js/jquery.fancybox.min.js')); ?>"></script>
<script>
  $(document).ready(function() {
      // add all to same gallery
      $(".gallery a").attr("data-fancybox", "mygallery");
      // assign captions and title from alt-attributes of images:
      $(".gallery a").each(function() {
          $(this).attr("data-caption", $(this).find("img").attr("alt"));
          $(this).attr("title", $(this).find("img").attr("alt"));
      });
      // start fancybox:
      $(".gallery a").fancybox();
  });
</script>
<script>
  $(document).ready(function() {
      $(".gallery a").fancybox();
  });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dewbxcak/rxcorporationbd.com/resources/views/website/index.blade.php ENDPATH**/ ?>