
<?php $__env->startSection('admin-content'); ?>
<div class="container-fluid">

    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <h4 class="page-title">About Us</h4>

                <div class="state-information d-none d-sm-block">
                    <div class="state-graph">
                        <div id="header-chart-1"></div>
                        
                    </div>
                    <div class="state-graph">
                        <div id="header-chart-2"></div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<div class="page-content-wrapper">
    <?php if($errors->any()): ?>
        <div class="alert alert-primary">
            <ol>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="text-danger"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
        </div>
    <?php endif; ?>
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card m-b-20">
                <div class="card-body">
                    <form action="<?php echo e(route('about.us.update')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="">Slogan</label>
                                    <input type="text"   name="slogan" class="form-control" rows="10" value="<?php echo e($content->slogan); ?>" />
                                </div>
                                <div class="form-group">
                                    <label for="">Short Description</label>
                                    <textarea id="short_description"  name="short_description" rows="10"><?php echo e($content->short_description); ?></textarea>
                                </div>
                               
                                
                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="">About Description</label>
                                    <textarea id="aboutEditor"  name="about_description" rows="10"><?php echo e($content->about_description); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="">About Image</label>
                                   <input type="file" class="form-control" name="about_image" onchange="aboutUrl(this)">
                                <br/><img src="" alt="" id="previewImage" style="height: 100px;width:150px">
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-info">Update</button>
                    </form>
                    
                </div>
            </div>
         </div> <!-- end col -->
    </div> <!-- end row -->  
</div> <!-- container-fluid -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>
<script src="<?php echo e(asset('admin')); ?>/js/ckeditor.js"></script>
<script type="text/javascript">
    //<![CDATA[
    CKEDITOR.replace( 'editor1',
    {
    skin : 'office2003',
    height: '100%'
    });
    //]]>
    </script>
<script>
  
    ClassicEditor
        .create( document.querySelector( '#aboutEditor' ) )
        .catch( error => {
            console.error( error );
        } );
</script>
<script>
  
    ClassicEditor
        .create( document.querySelector( '#short_description' ) )
        .catch( error => {
            console.error( error );
        } );
</script>
<script> 
    function aboutUrl(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload=function(e) {
                    $('#previewImage')
                        .attr('src', e.target.result)
                        .width(100);
                       
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
        document.getElementById("previewImage").src="<?php echo e(asset($content->about_image)); ?>";
        
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\aztibd\resources\views/admin/company_profile/about_us.blade.php ENDPATH**/ ?>