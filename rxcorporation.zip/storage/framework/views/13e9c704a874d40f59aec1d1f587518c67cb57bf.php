  <!-- ======= Header ======= -->
  
  <header id="header" class="sticky-top">
    <div class="container d-flex align-items-center">
      <?php
         $route = Route::current()->getName();
      ?>
      <h1 class="logo "><a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset($content->logo)); ?>" alt=""></a> </h1>
       
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar order-last ms-auto order-lg-0">
        <ul>
          <li><a class="<?php echo e(($route == 'home')?'active':''); ?>" href="<?php echo e(route('home')); ?>">Home</a></li>
          
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" role="button" aria-expanded="false">
              Product
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <li class="nav-item">
                <a class="dropdown-item" href="<?php echo e(route('product.show')); ?>" id="navbarDropdown1">All Product</a>
              </li>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                  $product = App\Models\Product::where('category_id', $item->id)->orderBy('name', 'ASC')->get();
                  $productCount = $product->count();
              ?>
              <li class="nav-item dropdown">
                  <a class="nav-link dropdown-item d-flex justify-content-between" href="<?php echo e(route('product-cat.show', $item->slug)); ?>" id="navbarDropdown1" aria-expanded="false">
                      <span class="submenu"><?php echo e($item->name); ?></span><?php if($productCount): ?><span class="icon"><i class="fas fa-caret-right"></i></span><?php endif; ?>
                  </a>
                  <?php if($productCount): ?>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a class="dropdown-item" href="<?php echo e(route('product.details', $item2->slug)); ?>"><?php echo e($item2->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                  <?php endif; ?>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </li>
          <li><a class="<?php echo e(($route == 'about')?'active':''); ?>"  href="<?php echo e(route('about')); ?>">About Us</a></li>
          
          
          <li><a class="<?php echo e(($route == 'gallery.show')?'active':''); ?>"  href="<?php echo e(route('gallery.show')); ?>">Photo Gallery</a></li>
          <li><a class="<?php echo e(($route == 'contact')?'active':''); ?>" href="<?php echo e(route('contact')); ?>">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

     

    </div>
  </header><!-- End Header --><?php /**PATH D:\xampp\htdocs\mehedi\rxcorporation\resources\views/partial/website_header.blade.php ENDPATH**/ ?>