<?php $__env->startPush('admin-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/css/dataTables.bootstrap4.min">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-content'); ?>
<div class="container-fluid">

    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <h4 class="page-title">Product Table</h4>

                <div class="state-information d-none d-sm-block">
                    <div class="state-graph">
                        <div id="header-chart-1"></div>
                        <div class="info"><a href="<?php echo e(route('product.create')); ?>" class="btn btn-primary">Add Product</a></div>
                    </div>
                    <div class="state-graph">
                        <div id="header-chart-2"></div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<div class="page-content-wrapper">
    <?php if($errors->any()): ?>
        <div class="alert alert-primary">
            <ol>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="text-danger"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
        </div>
    <?php endif; ?>
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card m-b-20">
                <div class="card-body">
                    <h4 class="mt-0 header-title">User Table</h4>
                    

                    <table id="example" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr class="text-center">
                                <th>SL</th>
                                <th>Name</th>
                                <th>Category</th>
                                <th>Short Description</th>
                                <th>Image</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->category->name); ?></td>
                                <td><?php echo $item->short_des; ?></td>
                                <td class="text-cener">
                                    <img src="<?php echo e(asset($item->image)); ?>" alt="" class="table-img">
                                </td>
                                <td width="15%">
                                    <a href="<?php echo e(route('product.edit',$item->id)); ?>" class="btn btn-info"><i class="fas fa-edit"></i></a>
                                    
                                    <button type="submit" class="btn btn-primary" onclick="deleteUser(<?php echo e($item->id); ?>)"><i class="fas fa-trash"></i></button>
                                    <form id="delete-form-<?php echo e($item->id); ?>" action="<?php echo e(route('product.destroy', $item)); ?>"
                                        method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                   
                                </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
              
                    
                </div>
            </div>
         </div> <!-- end col -->
    </div> <!-- end row -->  
</div> <!-- container-fluid -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>
<script src="<?php echo e(asset('admin')); ?>/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/sweetalert2.all.js"></script>
<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<script>
    function deleteUser(id) {
      swal({
          title: 'Are you sure?',
          text: "You want to Delete this!",
          type: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, delete it!',
          cancelButtonText: 'No, cancel!',
          confirmButtonClass: 'btn btn-success',
          cancelButtonClass: 'btn btn-danger',
          buttonsStyling: false,
          reverseButtons: true
      }).then((result) => {
          if (result.value) {
              event.preventDefault();
              document.getElementById('delete-form-' + id).submit();
          } else if (
              // Read more about handling dismissals
              result.dismiss === swal.DismissReason.cancel
          ) {
              swal(
                  'Cancelled',
                  'Your data is safe :)',
                  'error'
              )
          }
      })
  }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dewbxcak/rxcorporationbd.com/resources/views/admin/product/index.blade.php ENDPATH**/ ?>