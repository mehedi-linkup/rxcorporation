
<?php $__env->startSection('admin-content'); ?>
<div class="container-fluid">

    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <h4 class="page-title">Company Profile</h4>

                <div class="state-information d-none d-sm-block">
                    <div class="state-graph">
                        <div id="header-chart-1"></div>
                        
                    </div>
                    <div class="state-graph">
                        <div id="header-chart-2"></div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<div class="page-content-wrapper">
    <div class="card m-b-20">
        <div class="card-body">
            <h4 class="mt-0 header-title">Company Profile </h4>
            <?php if($errors->any()): ?>
            <div class="alert alert-primary">
                    <ol>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="text-danger"><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                </div>
            <?php endif; ?>
    <form class="" action="<?php echo e(route('company.update',$content)); ?>" method="POST" enctype="multipart/form-data" id="companyForm">
        <div class="row">
            <div class="col-lg-6">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Name</label>
                    <input type="text" value="<?php echo e($content->company_name); ?>" name="company_name" class="form-control" required placeholder="Type something"/>
                    <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span> 
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                </div>
                <div class="form-group">
                    <label>Phone 1</label>
                    <div>
                        <input data-parsley-type="number" value="<?php echo e($content->phone_1); ?>" name="phone_1" type="text"
                                class="form-control" required
                                placeholder="Enter only numbers"/>
                    </div>
                </div>
                <div class="form-group">
                    <label>Phone 2</label>
                    <div>
                        <input data-parsley-type="number" value="<?php echo e($content->phone_2); ?>" name="phone_2" type="text"
                                class="form-control" required
                                placeholder="Enter only numbers"/>
                    </div>
                </div>
                <div class="form-group">
                    <label>E-Mail</label>
                    <div>
                        <input type="email" class="form-control" value="<?php echo e($content->email); ?>" name="email" required
                                parsley-type="email" placeholder="Enter a valid e-mail"/>
                                
                    </div>
                </div>
                <div class="form-group">
                    <label>Facebook</label>
                    <div>
                        <input type="url" class="form-control" value="<?php echo e($content->facebook); ?>" name="facebook" 
                                parsley-type="email" placeholder="Enter a valid e-mail"/>
                                
                    </div>
                </div>
                <div class="form-group">
                    <label>Twitter</label>
                    <div>
                        <input type="url" class="form-control" value="<?php echo e($content->twitter); ?>" name="twitter" 
                                parsley-type="email" placeholder="Enter a valid e-mail"/>
                                
                    </div>
                </div>
                

            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label>Instagram</label>
                    <div>
                        <input type="url" class="form-control" value="<?php echo e($content->instagram); ?>" name="instagram" 
                                placeholder="Enter a valid e-mail"/>
                                
                    </div>
                </div>
                <div class="form-group">
                    <label>Linkedin</label>
                    <div>
                        <input type="url" class="form-control" value="<?php echo e($content->linkedin); ?>" name="linkedin" 
                                 placeholder="Enter a facebook url"/>
                                
                    </div>
                </div>
                <div class="form-group">
                    <label>Address</label>
                    <div>
                        <textarea name="address" class="form-control" rows="5" placeholder="Address"><?php echo e($content->address); ?>

                        </textarea>
                    </div>
                </div>
                <div class="form-group">
                    <label>Logo</label>
                    <div>
                        <input type="file" class="form-control"  name="logo" onchange="aboutUrl(this);" >
                    </div>
                </div>
                <div class="form-group">
                <img src="" alt="" id="previewImage">
                </div>
                
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <div>
                        <button type="submit" class="btn btn-primary waves-effect waves-light">
                            Update
                        </button>
                        <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                            Cancel
                        </button>
                    </div>
                </div>
            </div>
                   
        </form>

                </div>
            </div>
        </div> <!-- end col -->

    </div> <!-- end row -->  
</div> <!-- container-fluid -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>
<script> 
    function aboutUrl(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload=function(e) {
                    $('#previewImage')
                        .attr('src', e.target.result)
                        .width(100);
                       
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
        document.getElementById("previewImage").src="<?php echo e(asset($content->logo)); ?>";
        
    </script>
        <script>
            $('#companyForm').validate({ // initialize the plugin
            
               rules: {
                   name: {
                       required: true,
                   },
                   phone_1: {
                   required: true,
                   digits: true
                   },
                   phone_2: {
                   digits: true
                   },
                   email: {
                       required: true
                   },
                   logo: {
                   required: true
                   },
                   facebook:{
                       url:true,
                   }
                   twitter:{
                       url:true,
                   }
                   linkedin:{
                       url:true,
                   }
                   instagram:{
                       url:true,
                   }
               }
           
           });
            
           </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dewbxcak/rxcorporationbd.com/resources/views/admin/company_profile/index.blade.php ENDPATH**/ ?>