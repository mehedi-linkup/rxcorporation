  <!-- ======= Header ======= -->
  <section class="header-top">
      <div class="container d-flex">
        <div class="header-left"><i class="fas fa-phone-alt"></i> <?php echo e($content->phone_1); ?></div>
        <div class="header-right ms-auto">
          <div class="social-links text-md-right pt-3 pt-md-0">
            <a href="<?php echo e($content->twitter); ?>" target="_blank" class="twitter social-a"><i class="fab fa-twitter"></i></a>
            <a href="<?php echo e($content->facebook); ?>" target="_blank" class="facebook social-a"><i class="fab fa-facebook-f"></i></a>
            <a href="<?php echo e($content->instagram); ?>" target="_blank" class="instagram social-a"><i class="fab fa-instagram"></i></a>
            <a href="<?php echo e($content->linkedin); ?>" target="_blank" class="linkedin social-a"><i class="fab fa-linkedin-in"></i></a>
          </div>
        </div>
      </div>
  </section>
  <header id="header" class="sticky-top">
    <div class="container d-flex align-items-center">
      <?php
         $route = Route::current()->getName();
      ?>
      <h1 class="logo "><a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset($content->logo)); ?>" alt=""></a> </h1>
       <div class=" me-auto"><h3 class="comapnay-name"><?php echo e($content->company_name); ?></h3></div>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="<?php echo e(($route == 'home')?'active':''); ?>" href="<?php echo e(route('home')); ?>">Home</a></li>
          <li><a class="" href="<?php echo e(route('product.show')); ?>">Product</a></li>
          <li><a class="<?php echo e(($route == 'about')?'active':''); ?>"  href="<?php echo e(route('about')); ?>">About Us</a></li>
          <li><a class="<?php echo e(($route == 'management.show')?'active':''); ?>" href="<?php echo e(route('management.show')); ?>">Management</a></li>
          <li><a class="<?php echo e(($route == 'team.show')?'active':''); ?>" href="<?php echo e(route('team.show')); ?>">Team</a></li>
          <li><a class="<?php echo e(($route == 'gallery.show')?'active':''); ?>"  href="<?php echo e(route('gallery.show')); ?>">Photo Gallery</a></li>
          <li><a class="<?php echo e(($route == 'contact')?'active':''); ?>" href="<?php echo e(route('contact')); ?>">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

     

    </div>
  </header><!-- End Header --><?php /**PATH /home/dewbxcak/rxcorporationbd.com/resources/views/partial/website_header.blade.php ENDPATH**/ ?>