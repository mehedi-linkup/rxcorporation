
<?php $__env->startSection('website-content'); ?>
<main id="main">
    <div class="breadcrumbs" data-aos="fade-in">
        <div class="container">
          <h2>About Us</h2>
        </div>
      </div><!-- End Breadcrumbs -->
    
      <section id="about" class="about">
        <div class="container" data-aos="fade-up">
  
          <div class="row">
            <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-left" data-aos-delay="100">
              <img src="<?php echo e(asset($content->about_image)); ?>" class="img-fluid" alt="">
            </div>
            <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
              <h3><?php echo e($content->company_name); ?></h3>
              <?php echo $content->about_description; ?>

            </div>
          </div>
  
        </div>
      </section><!-- End About Section -->

      

  </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\rxcorporation\resources\views/website/about.blade.php ENDPATH**/ ?>